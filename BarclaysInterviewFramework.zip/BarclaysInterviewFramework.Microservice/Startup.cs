﻿using Microsoft.Owin;
using Owin;
using System.Web.Http;
using Unity;
using Unity.AspNet.WebApi;

[assembly: OwinStartup(typeof(BarclaysInterviewFramework.Microservice.Startup))]
namespace BarclaysInterviewFramework.Microservice
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            HttpConfiguration httpConfiguration = new HttpConfiguration();
            WebApiConfig.Register(httpConfiguration);

            var resolver = new UnityDependencyResolver(UnityConfig.Container);
            httpConfiguration.DependencyResolver = resolver;

            app.UseWebApi(httpConfiguration);
        }
    }
    
}