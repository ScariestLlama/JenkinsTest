﻿using System.Web.Mvc;

namespace BarclaysInterviewFramework.Microservice.Controllers
{
    public class InterviewController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Phase1()
        {
            return View();
        }

        public ActionResult Phase2()
        {
            return View();
        }

        public ActionResult Completion()
        {
            return View();
        }
    }
}