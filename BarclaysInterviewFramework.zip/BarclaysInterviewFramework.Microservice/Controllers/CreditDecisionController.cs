﻿using BarclaysInterviewFramework.Core.Candidate;
using System.Web.Http;
using System.Web.Http.Description;
using ThirdPartyPartner.Decisioning;

namespace BarclaysInterviewFramework.Microservice.Controllers
{
    [RoutePrefix("api")]
    public class CreditDecisionController : ApiController
    {
        private readonly ICandidateDecisioningService _decisioningService;

        public CreditDecisionController(ICandidateDecisioningService decisioningService)
        {
            _decisioningService = decisioningService;
        }

        [HttpPost]
        [Route("credit-decision")]
        [ResponseType(typeof(DecisionResponse))]
        public IHttpActionResult Post([FromBody]DecisionRequest decisionRequest)
        {
            var decisionResult = _decisioningService.MakeDecision(decisionRequest);
            return Ok(decisionResult);
        }    

    }
}
