﻿using BarclaysInterviewFramework.Core.Candidate;
using BarclaysInterviewFramework.Core.Logging;
using System;
using ThirdPartyPartner.Decisioning;

namespace BarclaysInterviewFramework.CandidateWorkspace
{
    public class CandidateDecisioningService : ICandidateDecisioningService
    {
        private readonly ILogger _logger;

        public CandidateDecisioningService(ILogger logger)
        {
            _logger = logger;
        }

        public DecisionResponse MakeDecision(DecisionRequest decisionRequest)
        {
            CreditCheckService thirdPartyCreditCheckService;
            if (decisionRequest.Age < 18)
                throw new Exception("Cannot be younger than 18");
            if (decisionRequest.LoanAmount >= 100000)
                return new DecisionResponse { Decision = Decision.Rejected };
            if(decisionRequest.LoanType == LoanType.Personal && (decisionRequest.LoanAmount < 500 || decisionRequest.LoanAmount > 25000))
                return new DecisionResponse { Decision = Decision.Rejected };
            if (decisionRequest.LoanType == LoanType.Home && decisionRequest.LoanAmount < 7500)
                return new DecisionResponse { Decision = Decision.Rejected };
            if (decisionRequest.Age < 30 && decisionRequest.LoanAmount > 50000)
                return new DecisionResponse { Decision = Decision.Rejected };
            if (decisionRequest.LoanType == LoanType.Personal && (decisionRequest.InterestRate < 0 || decisionRequest.InterestRate > 20))
                return new DecisionResponse { Decision = Decision.Rejected };
            if (decisionRequest.LoanType == LoanType.Home && (decisionRequest.InterestRate < 1 || decisionRequest.InterestRate > 12))
                return new DecisionResponse { Decision = Decision.Rejected };
            
            var credCheck = new CreditCheckService();
            return credCheck.MakeDecision(decisionRequest);
            return new DecisionResponse { Decision = Decision.Referred };
        }
    }
}
