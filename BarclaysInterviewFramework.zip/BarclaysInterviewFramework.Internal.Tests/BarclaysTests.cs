﻿using BarclaysInterviewFramework.Microservice;
using BarclaysInterviewFramework.Microservice.Controllers;
using Microsoft.Owin.Testing;
using Newtonsoft.Json;
using NUnit.Framework;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using ThirdPartyPartner.Decisioning;

namespace BarclaysInterviewFramework.Internal.Tests
{
    public class BarclaysTests
    {
        private TestServer _server;

        [OneTimeSetUp]
        public void SetUp()
        {
            _server = TestServer.Create<Startup>();
        }

        [OneTimeTearDown]
        public void TearDown()
        {
            _server.Dispose();
        }
       
        [TestCase(14)]
        [TestCase(17)]
        [TestCase(16)]
        [TestCase(15)]
        [TestCase(10)]
        [TestCase(5)]
        [TestCase(1)]
        [TestCase(-1)]
        [TestCase(-5)]
        [TestCase(-10)]
        public void GivenACustomerWhoIsUnder18_WhenDecisioning_ThenErrorIsThrown(int age)
        {
            var request = DefaultRequest();
            request.Age = age;

            Assert.ThrowsAsync<Exception>(() =>
            {
                return GetResponse(request, (response) => { });
            });           
        }

        [TestCase(100000)]
        [TestCase(100001)]
        [TestCase(200000)]
        [TestCase(250000)]
        [TestCase(500000)]
        [TestCase(1100000)]
        [TestCase(1100001)]
        [TestCase(1200000)]
        [TestCase(1250000)]
        [TestCase(1500000)]
        public async Task GivenALoanAmountThatIsTooHigh_WhenDecisioning_ThenARejectedStatusIsGiven(int loanAmount)
        {
            var request = DefaultRequest();
            request.LoanAmount = loanAmount;

            await GetResponse(request, (response) =>
            {
                Assert.AreEqual(Decision.Rejected, response.Decision);
            });
        }

        [TestCase(25001)]
        [TestCase(30000)]
        [TestCase(35000)]
        [TestCase(40000)]
        [TestCase(45000)]
        [TestCase(50000)]
        [TestCase(55000)]
        [TestCase(60000)]
        [TestCase(65000)]
        [TestCase(70000)]
        public async Task GivenALoanAmountThatIsTooHighForAPersonalLoan_WhenDecisioning_ThenARejectedStatusIsGiven(int loanAmount)
        {
            var request = DefaultRequest();
            request.LoanType = LoanType.Personal;
            request.LoanAmount = loanAmount;

            await GetResponse(request, (response) =>
            {
                Assert.AreEqual(Decision.Rejected, response.Decision);
            });
        }

        [TestCase(499)]
        [TestCase(400)]
        [TestCase(350)]
        [TestCase(300)]
        [TestCase(250)]
        [TestCase(200)]
        [TestCase(150)]
        [TestCase(100)]
        [TestCase(50)]
        [TestCase(0)]
        public async Task GivenALoanAmountThatIsTooLowForAPersonalLoan_WhenDecisioning_ThenARejectedStatusIsGiven(int loanAmount)
        {
            var request = DefaultRequest();
            request.LoanType = LoanType.Personal;
            request.LoanAmount = loanAmount;

            await GetResponse(request, (response) =>
            {
                Assert.AreEqual(Decision.Rejected, response.Decision);
            });
        }

        [TestCase(7499)]
        [TestCase(7400)]
        [TestCase(6350)]
        [TestCase(5300)]
        [TestCase(4250)]
        [TestCase(3200)]
        [TestCase(2150)]
        [TestCase(1100)]
        [TestCase(500)]
        [TestCase(100)]
        public async Task GivenALoanAmountThatIsTooLowForAHomeLoan_WhenDecisioning_ThenARejectedStatusIsGiven(int loanAmount)
        {
            var request = DefaultRequest();
            request.LoanType = LoanType.Home;
            request.LoanAmount = loanAmount;

            await GetResponse(request, (response) =>
            {
                Assert.AreEqual(Decision.Rejected, response.Decision);
            });
        }

        [TestCase(50001, 29)]
        [TestCase(55000, 28)]
        [TestCase(60000, 27)]
        [TestCase(65000, 26)]
        [TestCase(70000, 25)]
        [TestCase(75000, 24)]
        [TestCase(80000, 23)]
        [TestCase(85000, 22)]
        [TestCase(90000, 21)]
        [TestCase(95000, 20)]
        public async Task GivenALoanAmountThatIsTooHighForSomeoneUnder30_WhenDecisioning_ThenARejectedStatusIsGiven(int loanAmount, int age)
        {
            var request = DefaultRequest();
            request.LoanType = LoanType.Home;
            request.Age = age;
            request.LoanAmount = loanAmount;

            await GetResponse(request, (response) =>
            {
                Assert.AreEqual(Decision.Rejected, response.Decision);
            });
        }

        [TestCase(-1)]
        [TestCase(21)]
        [TestCase(25)]
        [TestCase(100)]
        public async Task GivenAnInterestRateOutsideOfAllowedValuesForAPersonalLoan_WhenDecisioning_ThenARejectedStatusIsGiven(int interestRate)
        {
            var request = DefaultRequest();
            request.InterestRate = interestRate;

            await GetResponse(request, (response) =>
            {
                Assert.AreEqual(Decision.Rejected, response.Decision);
            });
        }

        [TestCase(0)]
        [TestCase(1)]
        [TestCase(2)]
        [TestCase(10)]
        [TestCase(11)]
        [TestCase(12)]
        [TestCase(13)]
        [TestCase(14)]
        [TestCase(20)]
        public async Task GivenAnInterestRateInsideOfAllowedValuesForAPersonalLoan_WhenDecisioning_ThenAnExpectedStatusIsGiven(int interestRate)
        {
            var request = ForcedStatusRequest();
            request.LoanType = LoanType.Personal;
            request.Age = 32;
            request.InterestRate = interestRate;

            await GetResponse(request, (response) =>
            {
                Assert.AreEqual(Decision.Accepted, response.Decision);
            });
        }

        [TestCase(-1)]
        [TestCase(0)]
        [TestCase(13)]
        [TestCase(14)]
        [TestCase(15)]
        public async Task GivenAnInterestRateOutsideOfAllowedValuesForAHomeLoan_WhenDecisioning_ThenARejectedStatusIsGiven(int interestRate)
        {
            var request = DefaultRequest();
            request.InterestRate = interestRate;
            request.LoanType = LoanType.Home;

            await GetResponse(request, (response) =>
            {
                Assert.AreEqual(Decision.Rejected, response.Decision);
            });
        }


        [TestCase(1)]
        [TestCase(2)]
        [TestCase(3)]
        [TestCase(4)]
        [TestCase(5)]
        [TestCase(10)]
        [TestCase(11)]
        [TestCase(12)]
        public async Task GivenAnInterestRateInsideOfAllowedValuesForAHomeLoan_WhenDecisioning_ThenAnExpectedStatusIsGiven(int interestRate)
        {
            var request = ForcedStatusRequest();
            request.LoanType = LoanType.Home;
            request.Age = 32;
            request.InterestRate = interestRate;

            await GetResponse(request, (response) =>
            {
                Assert.AreEqual(Decision.Accepted, response.Decision);
            });
        }

        [TestCase(10000, 30, Decision.Rejected)]
        [TestCase(20000, 31, Decision.Referred)]
        [TestCase(30000, 32, Decision.Accepted)]
        [TestCase(40000, 30, Decision.Rejected)]
        [TestCase(50000, 31, Decision.Referred)]
        [TestCase(60000, 32, Decision.Accepted)]
        [TestCase(70000, 30, Decision.Rejected)]
        [TestCase(80000, 31, Decision.Referred)]
        [TestCase(90000, 32, Decision.Accepted)]
        public async Task GivenARequestThatRequiresThirdPartyInput_WhenDecisioning_ThenAnExpectedStatusIsReturned(int loanAmount, int age, Decision expectedDecision)
        {
            var request = ForcedStatusRequest();
            request.Age = age;
            request.LoanAmount = loanAmount;

            await GetResponse(request, (response) =>
            {
                Assert.AreEqual(expectedDecision, response.Decision);
            });
        }

        [TestCase(10000, 33)]
        [TestCase(20000, 33)]
        [TestCase(30000, 33)]
        [TestCase(40000, 33)]
        [TestCase(50000, 33)]
        public void GivenARequestThatRequiresThirdPartyInput_WhenDecisioning_ThenAnExpectedErrorIsThrown(int loanAmount, int age)
        {
            var request = ForcedStatusRequest();
            request.Age = age;
            request.LoanAmount = loanAmount;

            Assert.ThrowsAsync<Exception>(() =>
            {
                return GetResponse(request, (response) => { });
            });
        }

        private async Task GetResponse(DecisionRequest request, Action<DecisionResponse> act)
        {    
            var content = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
            var result = await _server.HttpClient.PostAsync("api/credit-decision", content);
            var responseContent = await result.Content.ReadAsStringAsync();
            if(!result.IsSuccessStatusCode)
            {
                throw new Exception(responseContent);
            }
            var response = JsonConvert.DeserializeObject<DecisionResponse>(responseContent);
            act(response);          
        }

        private DecisionRequest DefaultRequest()
        {
            return new DecisionRequest
            {
                Age = 18,
                LoanType = LoanType.Personal,
                LoanAmount = 10000,
                Name = "Loan Applicant",
                InterestRate = 5
            };
        }

        private DecisionRequest ForcedStatusRequest()
        {
            return new DecisionRequest
            {
                Age = 18,
                LoanType = LoanType.Home,
                Name = "Force Decision",
                LoanAmount = 10000,
                InterestRate = 5
            };
        }

    }
}
