﻿using System;

namespace BarclaysInterviewFramework.Core.Logging
{
    public class DummyLogger : ILogger
    {
        public void Log(string message)
        {
            return;
        }
    }
}
