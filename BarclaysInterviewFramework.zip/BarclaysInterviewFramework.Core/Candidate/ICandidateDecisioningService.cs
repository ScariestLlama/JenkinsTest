﻿using ThirdPartyPartner.Decisioning;

namespace BarclaysInterviewFramework.Core.Candidate
{
    public interface ICandidateDecisioningService
    {
        DecisionResponse MakeDecision(DecisionRequest decisionRequest);
    }
}
