﻿namespace ThirdPartyPartner.Decisioning
{
    public class DecisionResponse
    {
        public Decision Decision { get; set; }
    }
}