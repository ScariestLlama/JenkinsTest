﻿namespace ThirdPartyPartner.Decisioning
{
    public enum Decision
    {
        Rejected,
        Referred,
        Accepted
    }
}