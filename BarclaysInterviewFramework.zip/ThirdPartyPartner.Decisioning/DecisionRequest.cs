﻿namespace ThirdPartyPartner.Decisioning
{
    public class DecisionRequest
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public decimal InterestRate { get; set; }
        public decimal LoanAmount { get; set; }
        public LoanType LoanType { get; set; }
    }
}