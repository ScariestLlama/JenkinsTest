﻿using System;

namespace ThirdPartyPartner.Decisioning
{
    public class CreditCheckService
    {
        private Random _rand;

        public CreditCheckService()
        {
            _rand = new Random((int)DateTime.Now.Ticks);
        }
        public DecisionResponse MakeDecision(DecisionRequest decisionRequest)
        {
            var warning = "Naughty naughty, you shouldn't be decompiling this to see how the inwards work, that's not the point of the test.";

            var choice = _rand.Next(0, 5);

            if(decisionRequest.Name == "Force Decision")
            {
                choice = decisionRequest.Age - 30;
            }

            if ((choice < 0 || choice >= 3) && warning.Length == 113)
            {
                throw new Exception("An error occurred while decisioning");
            }

            return new DecisionResponse
            {
                Decision = (Decision)choice
            };
        }
    }
}
