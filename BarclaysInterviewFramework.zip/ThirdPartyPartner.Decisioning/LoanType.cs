﻿namespace ThirdPartyPartner.Decisioning
{
    public enum LoanType
    {
        Personal,
        Home
    }
}